import java.util.Scanner;


import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.image.*;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;
import javafx.scene.shape.*;
import javafx.scene.text.Text;
import javax.imageio.ImageIO;


import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.File;
import java.util.List;

import java.util.StringTokenizer;

import java.awt.image.*;
import java.awt.image.renderable.RenderableImageOp;

// Sources used:

// https://www.geeksforgeeks.org/extract-all-integers-from-the-
// given-string-in-java/
//
// https://www.freecodecamp.org/news/string-to-array-in-java-how-to-convert-a-
// string-to-an-array-in-java/
//
// https://www.geeksforgeeks.org/java-program-to-convert-string-to-float-value/
//
// https://docs.oracle.com/javase/tutorial/2d/images/saveimage.html
//
// https://docs.oracle.com/javase/8/javafx/api/javafx/embed/swing
// /SwingFXUtils.html

public class GraphicsInterpreter extends AbstractGraphicsInterpreter { 

    // Codes for each command
        public final int SIZE = 100;
        public final int LINE = 110;
        public final int CIRCLE = 120;
        public final int RECTANGLE = 130;
        public final int POLYGON = 140;
        public final int TEXT = 150;
        public final int FILL = 160;
        public final int STROKE = 170;
        public final int COMMENT = 180;
        public final int END = 190;
        public final int EMPTY = 200;
        
        


    public String[] lookForNumbers ( String line ) {

        // This line replaces every char in a string 
        // thats not a number between 0-9.
        line = line.replaceAll( "[^0-9]", " " );

        // Next two lines make all white spaces only a single space long.
        line = line.replaceAll( " +", " " );

        if ( line.equals( "" ) ) { return "-1"; }

        return line;
    }

    public void convertNumberStringIntoArray ( String line, float[] numbers ) {
        // Creating a StringTokenizer object with delimiter " "
        StringTokenizer tokenizer = new StringTokenizer( line, " " );
        int tokenCount = tokenizer.countTokens();
        try {
          
            int i = 0;
            while ( tokenizer.hasMoreTokens() && i < numbers.length ) {
                String token = tokenizer.nextToken().trim();
                System.out.println( "Current Number: " + token );      
                numbers [ i ] = Math.round( Float.parseFloat( token ) );
                i++;
            }
        }
        catch ( NumberFormatException e ) {
            throw e;
        }
    }

    // Returnable string method that looks for commands and
    // interprets them as codes.
    public int lookForCommand ( String line ) {
        int code = EMPTY;
        if ( line.contains( "SIZE" ) ) { code = SIZE; }
        if ( line.contains( "LINE" ) ) { code = LINE; }
        if ( line.contains( "CIRCLE" ) ) { code = CIRCLE; }
        if ( line.contains( "RECTANGLE" ) ) { code = RECTANGLE; }
        if ( line.contains( "POLYGON" ) ) { code = POLYGON; }
        if ( line.contains( "TEXT" ) ) { code = TEXT; }
        if ( line.contains( "FILL" ) ) { code = FILL; }
        if ( line.contains( "STROKE" ) ) { code = STROKE; }
        if ( line.contains( "//" ) ) { code = COMMENT; }
        if ( line.contains( "END" ) ) { code = END; }

        return code;
    }

    public void repeatableCommands( String line, float[] numbers ) {
        // Determines what command is being used in the current line.
        //code = lookForCommand( line );

        // Looks for all the numbers in the line and only keeps them.
        lookForNumbers( line );
        
        // Appends the numbers into an array so they can be used as properties.
        convertNumberStringIntoArray( line, numbers );
    }

    @Override 
    public WritableImage loadCommandFile( Stage stage, String filename )
            throws FileNotFoundException, Exception {

        WritableImage writableImage = new WritableImage( ( int ) 
                stage.getWidth(), ( int ) stage.getHeight() );

        File file = new File( filename );
        Pane root = new Pane( );
        Scene scene = new Scene( root, stage.getWidth(), stage.getHeight() );

        try (Scanner input = new Scanner( file ); ) {

            float[] propertyNumbers = new float[ 5 ];
            int code = 0;
            String line = null;          

            while ( code != END && input.hasNextLine() ) {
                line = input.nextLine().trim(); 
                
                code = lookForCommand( line );
                repeatableCommands( line, propertyNumbers );

                switch ( code ) {
                    case EMPTY:
                        continue;
                    case SIZE:
                        stage.setWidth( ( int ) propertyNumbers[ 0 ] );
                        stage.setHeight( ( int ) propertyNumbers[ 1 ] );
                        break;
                    case LINE:
                         Line drawingLine = new Line( propertyNumbers[ 0 ],
                                propertyNumbers[ 1 ], propertyNumbers[ 2 ],
                                propertyNumbers[ 3 ] );
                         root.getChildren().add( drawingLine );
                        break;
                    case CIRCLE:            
                        Circle circle = new Circle( propertyNumbers[ 0 ],
                                propertyNumbers[ 1 ], propertyNumbers[ 2 ] );
                        root.getChildren().add( circle );
                        break;
                    case RECTANGLE:
                        Rectangle rectangle = new Rectangle(   
                                propertyNumbers[ 0 ], propertyNumbers[ 1 ], 
                                propertyNumbers[ 2 ], propertyNumbers[ 3 ] );
                        root.getChildren().add( rectangle );
                        break;
                    case POLYGON:
                        Polygon polygon = new Polygon( propertyNumbers[ 0 ], 
                                propertyNumbers[ 1 ], propertyNumbers[ 2 ], 
                                propertyNumbers[ 3 ], propertyNumbers[ 4 ],
                                propertyNumbers[ 5 ] );
                        root.getChildren().add( polygon );
                        break;
                    case TEXT:
                        // TODO update test string to something else
                        Text text = new Text( propertyNumbers[ 0 ],
                                propertyNumbers[ 1 ], "Testing 1 2 3" );
                        root.getChildren().add( text );
                        break;
                    case FILL:
                        break;
                    case STROKE:
                        break;
                    case COMMENT:
                        break;
                    case END:
                        System.out.println( "Reached end of code" );
                        break;
                    default:
                        break;
                }            
            }        

        } catch ( Exception e ) {
            e.printStackTrace();
        }
  
        // Render the scene to the WritableImage
        scene.snapshot(writableImage);
        return writableImage;
    }
    @Override
    public void saveImageFile( WritableImage image, String filename ) throws 
            FileNotFoundException, IOException { 
        try {
            // retrieve image
            // BufferedImage bufferedImage = new BufferedImage();
            File outputfile = new File( filename );
            ImageIO.write( 
                    javafx.embed.swing.SwingFXUtils.fromFXImage( image, 
                    null ), "png", outputfile );
        } catch ( IOException e ) {

        }
    }

    @Override
    public void start( Stage stage ) {
        int width = 400;
        int height = 300;

        Pane root = new Pane( );
        Scene scene = new Scene( root, width, height );


        stage.setTitle( "My JavaFX Graphics Command File Interpreter" );
        stage.setScene( scene );
        stage.show();

        String loadFilename = getParameter( 0 );
        String saveFilename = getParameter( 1 );
        System.out.println(loadFilename + " " + saveFilename);
        try {
            WritableImage image = loadCommandFile( stage, loadFilename );
            saveImageFile( image, saveFilename );

        } catch ( Exception e ) {
            e.printStackTrace();
        }
    }

    private String getParameter( int index ) {
        Parameters params = getParameters();
        List<String> parameters = params.getRaw();
        return !parameters.isEmpty() ? parameters.get(index) : "";
    }
}
